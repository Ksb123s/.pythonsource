// 로그아웃 클릭시 a 태그 기능 중지
// form 전송
document.querySelector("#logout").addEventListener("click", () => document.querySelector("#logoutForm").submit());
